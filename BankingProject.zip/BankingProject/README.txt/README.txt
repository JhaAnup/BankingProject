Online Banking System using C++

-------------------------------------------------

Description:
This is a console-based banking system implemented in C++ using Dev C++ IDE.  
Features include:

- Create new bank accounts with account holder name and unique account number.
- Deposit money into accounts.
- Withdraw money from accounts (with balance check).
- Transfer funds between accounts.
- Display account details.

-------------------------------------------------

How to Compile & Run:
1. Open Dev C++.
2. Open the file banking_system.cpp.
3. Click Execute → Compile & Run (or press F11).
4. Use the menu options in the console to interact with the system.

-------------------------------------------------

Author:
Anup CSE  
C++ Programming Intern  

-------------------------------------------------

Sample folder structure:

BankingProject/
 ├── banking_system.cpp
 ├── README.txt
 └── sample_output.txt

